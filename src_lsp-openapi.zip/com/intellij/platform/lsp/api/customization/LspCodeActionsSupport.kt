// Copyright 2000-2023 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package com.intellij.platform.lsp.api.customization

import com.intellij.platform.lsp.api.LspServer
import org.eclipse.lsp4j.CodeAction
import org.eclipse.lsp4j.Diagnostic
import org.jetbrains.annotations.ApiStatus

/**
 * Handles [CodeAction](https://microsoft.github.io/language-server-protocol/specification#codeAction) objects received from the LSP server.
 */
@ApiStatus.Experimental
open class LspCodeActionsSupport {
  /**
   * Creates [LspIntentionAction] for the specific [CodeAction]. Implementations may return `null` if they don't want to provide a quick fix
   * for this [codeAction].
   *
   * @param codeAction result of the
   * [textDocument/codeAction](https://microsoft.github.io/language-server-protocol/specification/#textDocument_codeAction) request to the
   * LSP server, which asked for quick fixes for a specific [Diagnostic] (see [CodeAction.diagnostics]).
   */
  open fun createQuickFix(lspServer: LspServer, codeAction: CodeAction): LspIntentionAction? {
    return LspIntentionAction(lspServer, codeAction)
  }
}
