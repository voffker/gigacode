// Copyright 2000-2023 JetBrains s.r.o. and contributors. Use of this source code is governed by the Apache 2.0 license.
package com.intellij.platform.lsp.api.requests

import com.intellij.platform.lsp.api.LspServer

/**
 * A [notification](https://microsoft.github.io/language-server-protocol/specification/#notificationMessage) that the IDE sends
 * to the LSP server, for example, one of the
 * [text document synchronization](https://microsoft.github.io/language-server-protocol/specification/#textDocument_synchronization)
 * notifications.
 */
abstract class LspClientNotification(val lspServer: LspServer) {
  /**
   * Typical implementation:
   *
   *     lspServer.lsp4jServer.foo(...)
   */
  abstract fun sendNotification()
}